package com.android.example.wordlistsql;

/**
 * Created by gokhansahin on 2.04.2018.
 */

public class WordItem {
    int Id;
    String Word;

    public WordItem() {

    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getWord() {
        return Word;
    }

    public void setWord(String word) {
        Word = word;
    }
}
