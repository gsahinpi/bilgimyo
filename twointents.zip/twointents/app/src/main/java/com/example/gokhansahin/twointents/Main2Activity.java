package com.example.gokhansahin.twointents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    Intent kotuniyet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent niyetneydi=getIntent();
        String senttext=niyetneydi.getStringExtra("mesaj");
        Log.d("!!!!!!",senttext);
        TextView t2=findViewById(R.id.text_message);
        t2.setText(senttext);
        kotuniyet=new Intent(this,MainActivity.class);


    }

    public void returnReply(View view) {
        Log.d("Button","in activity2");
        TextView t3=findViewById(R.id.editText_second);
        String cevap=""+t3.getText();
        kotuniyet.putExtra("mesaj2",cevap);
        startActivity(kotuniyet);

    }
}
