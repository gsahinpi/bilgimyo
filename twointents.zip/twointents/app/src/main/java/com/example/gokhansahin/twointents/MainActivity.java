package com.example.gokhansahin.twointents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    Intent niyet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        niyet=new Intent(this,Main2Activity.class);
        Intent cevap=getIntent();
      

            String reply = cevap.getStringExtra("mesaj2");
            if (reply !=null) {
                Log.d("Button", reply);
                TextView replytext = findViewById(R.id.text_header_reply);
                replytext.setVisibility(View.VISIBLE);
                replytext.setText(reply);
            }



    }

    public void launchSecondActivity(View view) {
        Log.d("Button","Buttonclicked");
        TextView t=findViewById(R.id.editText_main);
        String metin=  ""+t.getText();
        Log.d("Button",metin);
        niyet.putExtra("mesaj",metin);
        startActivity(niyet);

    }
}
