package com.example.gokhansahin.vogelrecyle1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;

import java.util.LinkedList;

public class MainActivity extends AppCompatActivity {
    LinkedList<myveri> veriler;
    RecyclerView ourrcyler;
    myadapter adap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        veriler=new LinkedList<myveri>();
        for (int i=0; i<50;i++)
        {
            veriler.add(new myveri("ilk satir"+i,"ikinci satir"+i));
        }//for i
        ourrcyler=findViewById(R.id.rcyclr1);
        adap=new myadapter(veriler,this);
        ourrcyler.setAdapter(adap);
        ourrcyler.setLayoutManager(new LinearLayoutManager(this));
    }
    public void  imageclick(View v)
    {
       //a Log.d("heyy","you");
        int size=veriler.size();
        adap.add(size,"ilk satir"+size,"ikinci satir"+size);
       ourrcyler .smoothScrollToPosition(size);



    }
    public void  deleteitem(View v)
    {
        //a Log.d("heyy","you");
        int size=veriler.size();
        adap.remove(size-1);
        ourrcyler .smoothScrollToPosition(size);



    }
}
