package com.example.gokhansahin.vogelrecyle1;

import android.content.Context;
//import android.support.v7.widget.Recycle;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.LinkedList;

/**
 * Created by gokhansahin on 26.03.2018.
 */

public class myadapter extends RecyclerView.Adapter< myadapter.myviewholder> {
    LinkedList<myveri> verilistesi;
    LayoutInflater inflater;

    public myadapter(LinkedList<myveri> input, Context c)
    {
        verilistesi=input;
        inflater=LayoutInflater.from(c);

    }


    class myviewholder extends RecyclerView.ViewHolder
    {
        TextView txt1;
        TextView txt2;
        myadapter ref;


        public myviewholder(View itemView, myadapter m) {
            super(itemView);
            m=ref;
            txt1=itemView.findViewById(R.id.firstLine);
            txt2=itemView.findViewById(R.id.secondLine);
            txt1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    txt1.setText("Tiklandi"+txt1.getText());

                }
            });
            txt2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    txt2.setText("Tiklandi"+txt2.getText());

                }
            });

        }
    }

    @Override
    public myviewholder onCreateViewHolder(ViewGroup parent, int viewType) {
        View verisunucuref=inflater.inflate(R.layout.rehberimsi,parent,false);

        return new myviewholder(verisunucuref,this);
    }

    @Override
    public void onBindViewHolder(myviewholder holder, int position) {

        String ilktext=verilistesi.get(position).getL1();
        String ikitext=verilistesi.get(position).getL1();
        holder.txt1.setText(ilktext);
        holder.txt2.setText(ikitext);
    }



    @Override
    public int getItemCount() {
        return verilistesi.size();
    }
    public void add(int position, String item1,String item2) {
        myveri item=new myveri(item1,item2);
        verilistesi.add(position, item);
        notifyItemInserted(position);
    }

    public void remove(int position) {
        verilistesi.remove(position);
        notifyItemRemoved(position);
    }
}
