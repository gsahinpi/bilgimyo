package com.example.gokhansahin.asyncrecycler;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private GoolebooksAdapter mAdapter;
    ArrayList<data>listofbooks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // listofbooks.add(new data("a1","a2","a3","a4"));
        //listofbooks.add(new data("b1","b2","b3","b4"));

    }

    public void searchbooks(View view) {
        listofbooks=new ArrayList<data>();
        EditText e=findViewById(R.id.plain_text_input);
        String search=e.getText().toString();
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerview);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

       // new FetchBook(listofbooks).execute(search);
        new FetchBook(mAdapter,mRecyclerView,this).execute(search);
       Log.d("neoluyo",listofbooks.size()+"");




       //
        // Give the recycler view a default layout manager.



    }
}
