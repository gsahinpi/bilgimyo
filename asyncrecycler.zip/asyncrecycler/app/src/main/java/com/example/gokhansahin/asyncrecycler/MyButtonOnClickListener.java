package com.example.gokhansahin.asyncrecycler;

import android.view.View;

/**
 * Created by gokhansahin on 14.05.2018.
 */

class MyButtonOnClickListener implements View.OnClickListener {
    data dat;

    public MyButtonOnClickListener(data d) {
        dat = d;
    }

    public void onClick(View v) {
        // Implemented in WordListAdapter

    }

    public data getDat() {
        return dat;
    }
}
