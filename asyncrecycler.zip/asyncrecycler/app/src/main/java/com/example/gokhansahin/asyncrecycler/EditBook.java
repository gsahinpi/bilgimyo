package com.example.gokhansahin.asyncrecycler;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class EditBook extends AppCompatActivity {
    TextView t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_book);
        data uobj= getIntent().getParcelableExtra("datasent");
       TextView t1=findViewById(R.id.textView);
       TextView t2=findViewById(R.id.textView2);
        TextView t3=findViewById(R.id.textView3);
        TextView t4=findViewById(R.id.textView4);
        t1.setText(uobj.getSubtitle());
        t2.setText(uobj.getDescription());
        t3.setText(uobj.getPublishedDate());
       t4.setText(uobj.getPublisher());

    }
}
