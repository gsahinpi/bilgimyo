package com.example.gokhansahin.asyncrecycler;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by gokhansahin on 15.04.2018.
 */

public class FetchBook extends AsyncTask <String,Void,String>{
    private ArrayList<data> lbooks;
    private RecyclerView aRecyclerView;
    private RecyclerView.Adapter aAdapter;
    Context c;


    public FetchBook(ArrayList<data> listofbooks) {
        lbooks=listofbooks;
    }

    public FetchBook(GoolebooksAdapter mAdapter, RecyclerView mRecyclerView,Context con) {
        aAdapter=mAdapter;
        aRecyclerView=mRecyclerView;
        c=con;
    }

    @Override
    protected String doInBackground(String... strings) {
        return NetworkUtils.getBookInfo(strings[0]);

    }

    @Override
    protected void onPostExecute(String s) {
        lbooks=new ArrayList<data>();
        super.onPostExecute(s);
        Log.d("ne",s);
        try {
            JSONObject jsonObject = new JSONObject(s);
            JSONArray itemsArray = jsonObject.getJSONArray("items");
            Log.d("num2", String.valueOf(itemsArray.length()));
            for(int i = 0; i<itemsArray.length(); i++){
                JSONObject book = itemsArray.getJSONObject(i);
                String title=null;
                String authors=null;
                JSONObject volumeInfo = book.getJSONObject("volumeInfo");
                String  subtitle=null;;
                String publisher=null;;
                String       publishedDate=null;
                String description=null;

                try {
                    title = volumeInfo.getString("title");
                    try
                    {
                        authors = volumeInfo.getString("authors");
                    }catch (Exception e)
                    {
                        authors="unknown";
                    }
                    try
                    {
                        subtitle=volumeInfo.getString("subtitle");;
                    }catch (Exception e)
                    {
                        subtitle=title;
                    }
                    try
                    {
                        publisher=volumeInfo.getString("publisher");
                    }catch (Exception e)
                    {
                        publisher="unknown";
                    }
                    try
                    {
                          publishedDate=volumeInfo.getString(" publishedDate");
                    }catch (Exception e)
                    {
                        publishedDate="unknown";
                    }
                    try
                    {
                   description=volumeInfo.getString("description");
                    }catch (Exception e)
                    {
                        description="unknown";
                    }



;                    data dummy=new data(subtitle,publisher,publishedDate,description);
                    lbooks.add(dummy);
                    Log.d("neoluyo",lbooks.get(0).getSubtitle());


                } catch (Exception e){
                    e.printStackTrace();
                }



            }//for

            aAdapter = new GoolebooksAdapter(c,lbooks);
            aRecyclerView.setAdapter(aAdapter);
            Log.d("num", String.valueOf(lbooks.size()));



        } catch (Exception e){

            e.printStackTrace();
        }


    }
}
